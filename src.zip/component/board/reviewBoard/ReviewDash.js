import React from 'react';
import ListReview from './ListReview';

const ReviewDash = () => (
    <div className='container__list'>
        <ListReview />
    </div>
);

export default ReviewDash;