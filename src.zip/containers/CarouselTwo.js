// import React from 'react';

// function CarouselTwo() {
//   return (
//     <div className="col-md-6 two-items-bottom-items">
//       <h2>Two items</h2>
//       <div className="owl-carousel owl-carousel2">
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k4.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k4.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k2.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k2.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k3.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k3.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k1.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k1.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k4.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k4.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//         <div>
//           <div className="product-item">
//             <div className="pi-img-wrapper">
//               <img src="/assets/frontend/pages/img/products/k3.jpg" className="img-responsive" alt="Berry Lace Dress" />
//               <div>
//                 <a href="/assets/frontend/pages/img/products/k3.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                 <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//               </div>
//             </div>
//             <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//             <div className="pi-price">$29.00</div>
//             <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default CarouselTwo;