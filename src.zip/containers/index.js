export { default as Header } from './Header';
export { default as PreHeader } from './PreHeader';
export { default as CarouselFull } from './CarouselFull';
export { default as CarouselThree } from './CarouselThree';
export { default as CarouselTwo } from './CarouselTwo';


// export { default as CheckOut } from './CheckOut';
// export { default as Error404 } from './Error404';
// export { default as Error500 } from './Error500';
export { default as Home } from './Home';
export {default as PreFooter} from './PreFooter';
export {default as Footer} from './Footer';