// import React from 'react';

// function CarouselThree() {
//   return (
//     <div class="row margin-bottom-40 ">
//       <div className="col-md-9 col-sm-8">
//         <h2>Three items</h2>
//         <div className="owl-carousel owl-carousel3">
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k1.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k1.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//               <div className="sticker sticker-new" />
//             </div>
//           </div>
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k2.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k2.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress2</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//             </div>
//           </div>
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k3.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k3.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress3</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//             </div>
//           </div>
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k4.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k4.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress4</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//               <div className="sticker sticker-sale" />
//             </div>
//           </div>
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k1.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k1.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress5</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//             </div>
//           </div>
//           <div>
//             <div className="product-item">
//               <div className="pi-img-wrapper">
//                 <img src="/assets/frontend/pages/img/products/k2.jpg" className="img-responsive" alt="Berry Lace Dress" />
//                 <div>
//                   <a href="/assets/frontend/pages/img/products/k2.jpg" className="btn btn-default fancybox-button">Zoom</a>
//                   <a href="#product-pop-up" className="btn btn-default fancybox-fast-view">View</a>
//                 </div>
//               </div>
//               <h3><a href="shop-item.html">Berry Lace Dress6</a></h3>
//               <div className="pi-price">$29.00</div>
//               <a href="javascript:;" className="btn btn-default add2cart">Add to cart</a>
//             </div>
//           </div>
//         </div>
//       </div>
//     </div>
//   );
// }

// export default CarouselThree;